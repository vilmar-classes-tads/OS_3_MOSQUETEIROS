/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.ifpe.recife.projetogct;

import java.util.ArrayList;

/**
 *
 * @author ALUNOS
 */
public class Usuario{
    String nome;
    String CPF;
    String email;
    Perfil perfis[];

    public Usuario() {
        this.perfis = new ArrayList<>();
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCPF() {
        return CPF;
    }

    public void setCPF(String CPF) {
        this.CPF = CPF;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Perfil[] getPerfis() {
        return perfis;
    }

    public void setPerfis(Perfil[] perfis) {
        this.perfis = perfis;
    }
    
    
    
}
