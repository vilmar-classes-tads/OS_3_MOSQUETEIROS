/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.edu.ifpe.recife.projetogct;

/**
 *
 * @author ALUNOS
 */
public class ProjetoGCT {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
